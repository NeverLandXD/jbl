const information = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/556993899391
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


                     𝚉𝙴𝚄𝚂

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}bahasa*
║➩ ❍ *${prefix}kodenegara*
║➩ ❍ *${prefix}kbbi*
║➩ ❍ *${prefix}fakta*
║➩ ❍ *${prefix}infocuaca*
║➩ ❍ *${prefix}infogempa*
║➩ ❍ *${prefix}jadwaltvnow*
║➩ ❍ *${prefix}covidcountry*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.information = information
